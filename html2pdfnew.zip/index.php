<?php
header('Content-Type: text/html; charset=utf-8');
require_once 'html2pdf/vendor/autoload.php';
use Spipu\Html2Pdf\Html2Pdf;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;
try {
    ob_start()
    ?>
    <style type="text/css">
        table.page_header {width: 100%; border: none; padding: 2mm 11mm 1mm; font-family: DejaVuSans }
        table.page_footer {width: 100%; border: none; padding: 2mm 11mm 0mm; font-family: DejaVuSans}
        table.page_body {width: 100%; border: none; padding: 32mm 11mm 25mm; font-family: DejaVuSans}
        table {width: 100%; border: none;}
        td { color: #000000; font-size: 14px; line-height: 1.4;}
        td.theme_color {color: #dd3333;}
        table.page_footer .page_footer_info td {font-size: 9px}
    </style>
    <page>
        <?php include('/page_header.php'); ?>
        <?php include('/page_footer.php'); ?>
        <table class="page_body">
            <tr>
                <td style="width: 100%; text-align: left; padding-top: 40px">
                    <table>
                        <tr>
                            <td style="width: 100%; text-align: left;">
                                <table>
                                    <tr>
                                        <td style="width: 30%; vertical-align: top;text-align: right">
                                            Ngày tiếp nhận đăng ký:
                                        </td>
                                        <td style="width: 70%;vertical-align: top;">
                                            [get_current_date]
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%; vertical-align: top;text-align: right">
                                            Kênh đăng ký:
                                        </td>
                                        <td style="width: 70%;vertical-align: top;">
                                            Đăng ký qua website www.cdics.net
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td class="theme_color" style="width: 100%; text-align: center;font-size: 28px;padding: 30px 0">
                    <b>ĐĂNG KÝ TƯ VẤN DI TRÚ</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;font-size: 16px;padding: 5px 0 20px">
                    <b>THÔNG TIN KHÁCH HÀNG</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;">
                    <table>
                        <tr>
                            <td style="width: 100%; text-align: left;">
                                <table>
                                    <tr>
                                        <td style="width: 25%; vertical-align: top;text-align: right">
                                            Khách hàng:
                                        </td>
                                        <td style="width: 75%;vertical-align: top;">
                                            {name}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 25%; vertical-align: top;text-align: right">
                                            Email:
                                        </td>
                                        <td style="width: 75%;vertical-align: top;">
                                            {email}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 25%; vertical-align: top;text-align: right">
                                            Điện thoại:
                                        </td>
                                        <td style="width: 75%;vertical-align: top;">
                                            {phonenumber}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 25%; vertical-align: top;text-align: right">
                                            Ngày tư vấn:
                                        </td>
                                        <td style="width: 75%;vertical-align: top;">
                                            {date}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 25%; vertical-align: top;text-align: right">
                                            Giờ tư vấn:
                                        </td>
                                        <td style="width: 75%;vertical-align: top;">
                                            {option}
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;font-size: 16px;padding: 20px 0 30px">
                    <b>NỘI DUNG MUỐN ĐƯỢC TƯ VẤN</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding: 5px;border: 1px solid #333333;">
                    {question}
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding: 30px 0">
                    Quý Khách hàng vui lòng kiểm tra nội dung bên trên. Nếu thông tin cần chỉnh sửa, Quý Khách hàng cần gửi lại một đăng ký mới.<br>
                    Công ty Canadian Dreams Immigration sẽ liên lạc với Quý Khách hàng trong vòng 48 giờ để ghi nhận thêm một số thông tin và bắt đầu tư vấn.
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding: 5px 5px 25px;border: 1px solid #333333;">
                    Khách hàng: đã đọc và cam kết theo nội dung đã cung cấp theo Bản Cam kết Cung cấp Thông tin và Bảo mật thông tin qua website www.cdics.net này.
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 25px;">
                    Cam kết điện tử này có giá trị pháp lý như bản ký tay theo quy định của Luật pháp Canada.
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 25px;">
                    Trân trọng cảm ơn Quý Khách hàng đã liên hệ Canadian Dreams Immigration!
                </td>
            </tr>
        </table>
    </page>
    <page>
        <?php include('/page_header.php'); ?>
        <?php include('/page_footer.php'); ?>
        <table class="page_body">
            <tr>
                <td style="width: 100%; text-align: center;font-size: 16px;padding: 15px">
                    <b>CAM KẾT CUNG CẤP THÔNG TIN VÀ BẢO MẬT THÔNG TIN</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;">
                    Bản cam kết này thực hiện vào [get_current_date type='1'] khi khách hàng đăng ký tư vấn di trú
                    trên website www.cdics.net.
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 15px;">
                    <table>
                        <tr>
                            <td style="width: 15%;vertical-align: top;">
                                GIỮA
                            </td>
                            <td style="width: 85%;vertical-align: top;">
                                <b>CANADIAN DREAMS IMMIGRATION CONSULTING SERVICES - CDICS</b><br>
                                Đại diện là Tổng Giám Đốc<br>
                                Mr. Andrew TuanAnh Duong, BSc, RCIC
                            </td>
                        </tr>
                        <tr>
                            <td style="width: 15%;vertical-align: top;padding-top: 10px;">
                                VÀ
                            </td>
                            <td style="width: 85%;vertical-align: top;padding-top: 10px;">
                                <b>KHÁCH HÀNG TIỀM NĂNG</b><br>
                                Mr/Ms. {name}
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 15px;">
                    CĂN CỨ
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 10px;padding-left: 20px">
                    <b>•</b> Theo Quy Chế 4 – Quản Lý Thông Tin & Bảo Mật Thông Tin của <b>Bộ Quy Chế Công Ty 9-2019</b> do Hội Đồng Sáng Lập & Quản Trị Công ty ban hành;
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 10px;padding-left: 20px">
                    <b>•</b> Theo Quy Định QD04-01 Cam Kết Bảo Mật Thông Tin do Tổng Giám Đốc công ty ban hành;
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding-top: 10px;padding-left: 20px">
                    <b>•</b> Nguyện vọng của Khách hàng;
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: center;font-size: 15px;padding: 15px">
                    <b>TÔI CAM KẾT & CAM KẾT THỰC HIỆN</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;">
                    <b>1. Công ty cam kết Quản Lý Thông Tin của Khách hàng chuẩn mực và Bảo Mật Thông Tin của Khách hàng tuyệt đối</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;">
                    Là một công ty tư vấn luật của Canada, được Chính phủ Canada công nhận tính hợp pháp theo luật Canada, Canadian Dreams Immigration CDICS luôn đặt trách nhiệm quản lý thông tin và bảo mật thông tin của Khách hàng lên hàng đầu. Mọi vi phạm của Công ty làm ảnh hưởng đến quyền lợi của Khách hàng, dù là vô tình hay cố ý, gían tiếp hay trực tiếp, đều sẽ bị pháp luật Canada điều chỉnh. Do đó, Công ty cam kết tuân thủ nghiêm chỉnh quy định của Ủy Ban Quản Lý Tư Vấn Di Trú Canada ICCRC về thông tin và bảo mật thông tin cùng các luật pháp khác liên quan, với tối đa khả năng của mình, để sử dụng thông tin Khách hàng một cách chuẩn mực cũng như nghiêm ngặt trong việc bảo mật thông tin cho Khách hàng.
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-top: 10px">
                    <b>2. Khách hàng Đảm bảo Cung Cấp Thông Tin phù hợp</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 15px">
                    2.1 Thông tin cung cấp cần có đủ ba (3) yêu cầu cốt lõi: (1) Trung thực, (2) Chính xác, (3) Đầy đủ
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 15px">
                    2.2 Cập nhật thường xuyên: là một đặc tính không thay đổi, không thể khác cần có cho hồ sơ di trú do Công ty thực hiện, Khách hàng đồng cảm và cùng thực hiện;
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 15px">
                    2.3 Tính “tuyệt đối” của trách nhiệm này, tức phải áp dụng:
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    2.3.1 Trong mọi Hoàn cảnh
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    2.3.2 Tại mọi Thời điểm
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    2.3.3 Cho mọi bậc, hình thức, dạng, hay loại thông tin
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-top: 10px">
                    <b>3. Khách hàng cùng Công ty cam kết tuân thủ nghiêm quy định về Bảo Mật Thông Tin</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 15px">
                    <b>3.1 Không Chia Sẻ</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    Nếu không có sự cho phép bằng văn bản của 1 bên, bên kia tuyệt đối không được chia sẻ với bất cứ bên thứ ba nào, thông tin ở/trong/của bất cứ loại nào, bậc nào, dạng nào và hình thức nào. Ngoại trừ việc chia sẻ là bắt buộc theo Luật;
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 15px">
                    <b>3.2 Không Lợi Dụng:</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    Nếu không có sự cho phép bằng văn bản của 1 bên, bên kia tuyệt đối không được sử dụng cho mục đích cá nhân, thông tin ở/trong/của bất cứ loại nào, bậc nào, dạng nào và hình thức nào;
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 15px">
                    <b>3.3 Tính tuyệt đối của Bảo Mật Thông Tin:</b>
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    3.3.1 Trong mọi hòan cảnh
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    3.3.2 Tại mọi thời điểm
                </td>
            </tr>
            <tr>
                <td style="width: 100%;padding-left: 30px">
                    3.3.3 Cho mọi bậc, hình thức, dạng, hay loại thông tin
                </td>
            </tr>
            <tr>
                <td style="width: 100%; text-align: left;padding: 20px 0">
                    <table style="border-collapse: collapse; border-spacing: 0">
                        <tr>
                            <td style="width: 50%;border: 1px solid #333333;vertical-align: top; padding: 5px">
                                Khách hàng: đã đọc và cam kết theo nội dung nêu trên.
                            </td>
                            <td style="width: 50%;border: 1px solid #333333;vertical-align: top; padding: 5px">
                                Bản Cam kết Cung cấp Thông tin và Bảo mật thông tin qua website www.cdics.net này có giá trị pháp lý như bản ký tay theo quy định của Luật pháp Canada.
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </page>
    <?php
    $html = ob_get_contents();
    ob_end_clean();
    $html2pdf = new Html2Pdf('P', 'A4', 'en');
    $html2pdf->pdf->SetDisplayMode('real');
    $html2pdf->writeHTML($html);
    $pdfContent = $html2pdf->output(__DIR__.'/test.pdf', 'I');
    //$html2pdf->output(__DIR__.'/test.pdf', 'F');
} catch (Html2PdfException $e) {
    $formatter = new ExceptionFormatter($e);
    echo $formatter->getHtmlMessage();
}