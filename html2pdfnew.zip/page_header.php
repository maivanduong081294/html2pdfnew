<page_header>
    <table class="page_header">
        <tr>
            <td style="width: 100%; text-align: left;border-bottom: solid 1px #333;">
                <table>
                    <tr>
                        <td style="width: 15%; text-align: left">
                            <img style="width: 90px; vertical-align: middle; height: auto"
                                 src="http://khoweb.webgiare.net/cdic/wp-content/themes/cdics2021/images/logo-email.png"
                                 alt="Logo">
                        </td>
                        <td style="width: 85%; text-align: right;">
                            <table>
                                <tr>
                                    <td class="theme_color" style="width: 100%; text-align: right;font-size: 16px;">
                                        <b>Canadian Dreams Immigration Consulting Services – CDICS</b>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 100%; text-align: right;">
                                        <table>
                                            <tr>
                                                <td style="width: 60%; text-align: right;">
                                                    [W] www.cdics.net
                                                </td>
                                                <td style="width: 40%; text-align: right;">
                                                    [E] lienhe247@cdics.ne
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</page_header>