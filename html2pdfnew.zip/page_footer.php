<page_footer>
    <table class="page_footer">
        <tr>
            <td style="width: 100%; text-align: left;border-top: solid 1px #dd3333;">
                <table class="page_footer_info">
                    <tr>
                        <td style="width: 15%; vertical-align: top;font-style: italic;">
                            Đồng ý sử dụng thông tin cá nhân
                        </td>
                        <td style="vertical-align: top;width: 35%;">
                            TRỤ SỞ CHÍNH CDICS CANADA<br>
                            [A] 12-8465 Harvard Place, Chilliwack British Columbia V2P 7Z5<br>
                            [T] +1 (204) 808.8693 | +1 (604) 800.6864
                        </td>
                        <td style="vertical-align: top;width: 47%; padding-left: 10px ">
                            VĂN PHÒNG CDICS TẠI VIỆT NAM<br>
                            tòa nhà SOGETRACO, 30 Đặng Văn Ngữ, phường 10, quận Phú Nhuận, Tp. HCM, Việt Nam
                            <br>(+84-28)62.928.218 | (+84-9) 1797.5489
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td style="width: 100%; text-align: right">
                [[page_cu]]
            </td>
        </tr>
    </table>
</page_footer>